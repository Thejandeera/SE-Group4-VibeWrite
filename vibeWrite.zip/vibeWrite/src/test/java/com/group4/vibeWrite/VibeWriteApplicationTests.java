package com.group4.vibeWrite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VibeWriteApplicationTests {

	@Test
	void contextLoads() {
	}

}
